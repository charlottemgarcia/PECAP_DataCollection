function PECAP_Data = run_PECAP(param)

% PECAP_Data = run_PECAP(param)
%   takes the electrodes with the MCL levels collected from running the
%   loudness GUI, and collects ECAPs for every combination of masker and 
%   probe electrodes with the recording parameters specified within the 
%   param structure
%
%   Inputs:
%       - param:    structure containing recording parameters required for
%                   recording ECAPs
%   Outputs:
%       - PECAP_Data:   structure containing recorded ECAP data
%
% Required Software: 
%   signal_all = run_BEDCS_and_get_ECAP(h, param);
%   plot_ABCD_frames_AB(signal_all, param);
%   [a, details] = ecap_amplitude(ECAP, time_vector_ms, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 28 May 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% start timer
start = clock;

%% set diagonal parameters & initiate data structure
electrodes = param.electrodes;
MCL_levels = param.MCL_levels;
PECAP_Data = struct();
ii = 1; rec_move = 0;

%% Loop through different ECAP recordings
for pidx = 1:length(electrodes)
    % Set parameters for probe
    param.electrode_probe = electrodes(pidx);
    param.level_start_probe = MCL_levels(pidx);          
    
    % set maskers for the current row based on half/full PECAP parameter
    if param.fullmatrix == 1
        masker_cond = 1:length(electrodes);
    elseif param.fullmatrix == 0
        if param.rel_rec_EL < 0
            masker_cond = pidx:length(electrodes);
        elseif param.rel_rec_EL > 0
            masker_cond = 1:pidx;
        end
    end
    
    for midx = masker_cond
        % set parameters for masker
        param.electrode_masker = electrodes(midx);
        param.level_start_masker = MCL_levels(midx);  
        
        % set parameters for recording electrode
        if param.electrodes(pidx) + param.rel_rec_EL >= 1 && ...
                electrodes(pidx) + param.rel_rec_EL <= 16
            % avoid recording on the masker electrode
            if electrodes(midx) == electrodes(pidx) + param.rel_rec_EL
                param.rec_EL = electrodes(pidx) + param.rel_rec_EL + 1;
                rec_move = 1;
            else
                param.rec_EL = electrodes(pidx) + param.rel_rec_EL;
            end
        else
            % avoid recording on the probe electrode
            if electrodes(midx) == electrodes(pidx) - param.rel_rec_EL
                param.rec_EL = electrodes(pidx) - param.rel_rec_EL - 1;
                rec_move = 1;
            else
                param.rec_EL = electrodes(pidx) - param.rel_rec_EL;
            end
        end  
        
        % create stimulas structure to pass to BEDCS
        stim_struct.ELrec = param.rec_EL;     
        stim_struct.Tp = param.phase_duration_us;
        stim_struct.Tdel = param.masker_probe_delay_us;
        stim_struct.level = [param.level_start_masker ...
            param.level_start_probe];
        stim_struct.Imasker = param.level_start_masker;
        stim_struct.Iprobe = param.level_start_probe;
        stim_struct.ELmasker = param.electrode_masker;
        stim_struct.ELprobe = param.electrode_probe;
        
        % if we are on the diagonal, then record ABCD frames
        if param.electrodes(pidx) == param.electrodes(midx)
            param.exp_file = ...
                sprintf('ForwardMaskingMP_gain_%d_%dkHz_%d_repeats.bExp',...
                param.gain, param.fs_kHz, param.sweeps); 
        % also record all 4 frames if the rec elec has been shifted
        elseif rec_move
        param.exp_file = ...
                sprintf('ForwardMaskingMP_gain_%d_%dkHz_%d_repeats.bExp',...
                param.gain, param.fs_kHz, param.sweeps); 
        % if neither of the above, then only record BC frames
        else
            param.exp_file = ...
                sprintf('ForwardMaskingMP_BC_gain_%d_%dkHz_%d_repeats.bExp',...
                param.gain, param.fs_kHz, param.sweeps); 
        end
            
        % create handle to pass to BEDCS
        if param.debug
            handle_BEDCS = [];
        else
            handle_BEDCS = actxserver('BEDCS2.CBEDCSApp');
            handle_BEDCS.Online = 1;
            handle_BEDCS.Visible = 0;

            [current_path, ~, ~] = fileparts(mfilename('fullpath'));
            full_filename = [current_path filesep param.exp_file];

            % Load the file if not already done
            if ~strcmp(handle_BEDCS.ExpFileName, full_filename)
                handle_BEDCS.LoadExpFile(full_filename)
            end

            % Update the stimulus properties
            fields = fieldnames(stim_struct);
            for i = 1:length(fields)
                if ~strcmp(fields{i}, 'level')
                    handle_BEDCS.Let_ControlVarVal(fields{i},...
                        stim_struct.(fields{i}))
                end
            end
            
            % To allow stimulation above 24 uA in BEDCS verson 1.8.321
            % (this is unecessary in version 1.8.337)
            % this turns off the OLS error 
            handle_BEDCS.ULevelMode = 1;
            
        end
    
        % print out recording details
        if param.fullmatrix == 1
            fprintf(['\nPECAP Recording ' num2str(ii) ' of ' ...
                num2str(length(electrodes)^2) '\n']);
        elseif param.fullmatrix == 0
            fprintf(['\nPECAP Recording ' num2str(ii) ' of ' ...
                num2str(length(electrodes)^2/2 + ...
                floor(length(electrodes)/2)) '\n']);
        end
        fprintf('\tProbe EL:  %d\t\tProbe Level:  %d\n', ...
            param.electrodes(pidx), param.MCL_levels(pidx));
        fprintf('\tMasker EL: %d\t\tMasker Level: %d\n', ...
            param.electrodes(midx), param.MCL_levels(midx));
        fprintf('\tRecording EL: %d\n', param.rec_EL);
    
        % run BEDCS and collect ECAP
        tic
        % if on the diagonal, record all 4 frames
        if param.electrodes(pidx) == param.electrodes(midx)
            signal_all = run_BEDCS_and_get_ECAP(handle_BEDCS,param);
        % also record all 4 frames if the rec elec has been shifted
        elseif rec_move
            signal_all = run_BEDCS_and_get_ECAP(handle_BEDCS,param);
        % otherwise, only record BC frames
        else
            signal_all = run_BEDCS_and_get_BC(handle_BEDCS,param);
        end
        toc
    
        % store signal and details in another structure
        PECAP_Data(ii).Probe = stim_struct.ELprobe;
        PECAP_Data(ii).Probe_lvl = stim_struct.level(2);
        PECAP_Data(ii).Masker = stim_struct.ELmasker;
        PECAP_Data(ii).Masker_lvl = stim_struct.level(1);
        PECAP_Data(ii).Recording = stim_struct.ELrec;
        PECAP_Data(ii).PDus = stim_struct.Tp;
        PECAP_Data(ii).MPIus = stim_struct.Tdel;
        if isfield(signal_all,'ECAP')
            PECAP_Data(ii).ECAP = signal_all.ECAP;
        end
        PECAP_Data(ii).frames = signal_all;
        
        % iterate ii because I'm lazy
        ii = ii + 1;
        
        % reset whether the recording electrode was shifted over
        rec_move = 0;
    end
end

%% Use A and D frames from diagonal to interpolate ECAPs for non-diagonal

for ii = 1:length(PECAP_Data)
    % if the A and D frames don't already exist
    if ~isfield(PECAP_Data(ii).frames,'A')
        for jj = 1:length(PECAP_Data)
            % find the right A and D frames
            if PECAP_Data(ii).Probe == PECAP_Data(jj).Probe && ...
                    PECAP_Data(jj).Probe == PECAP_Data(jj).Masker
                % extract the diagonal recording's A and D frames
                A = PECAP_Data(jj).frames.A;
                D = PECAP_Data(jj).frames.D;
                % add a note for which recorded frame we're coppying from
                PECAP_Data(ii).frames.ADframesTrace = jj;
            end
        end
        % copy A and D frames from diagonal
        PECAP_Data(ii).frames.A = A;
        PECAP_Data(ii).frames.D = D;
        % use diagonal A and C frames to calculate ECAP for current ECAP
        PECAP_Data(ii).ECAP = A - (PECAP_Data(ii).frames.B - ...
            PECAP_Data(ii).frames.C) - D;
    end
end

%% print out elapsed time
finish = clock;
diff = finish - start;
if round(diff(6)) > 0
    fprintf('\nPECAP Total Elapsed Time: %d hours %d minutes %d seconds\n', ...
        diff(4), diff(5), round(diff(6)));
else
    fprintf('\nPECAP Total Elapsed Time: %d hours %d minutes %d seconds\n', ...
        diff(4), diff(5)-1, 60 + round(diff(6)));
end