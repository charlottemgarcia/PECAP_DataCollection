function [a, details, mask] = ecap_amplitude(v,t,param)

%[a, details, mask] = eCAP_amplitude(v,t,param)
%   Computes eCAP amplitude. Assumes the input t for time is in ms and the
%   voltage v is in mV. The two vectors must be the same length. Takes an
%   optional input of param (collected whilst recording ECAPs) to extract
%   the Masker-Probe Interval (MPI). If not provided, this is set to 500us.
%   
%   [...] = eCAP_amplitude(eCAPs) where eCAPs is the cell array produced by
%   get_eCAP_from_xls().
%
%   [...] = eCAP_amplitude(t, v) where t is the time vector and v is the
%   voltage.
%
%   [a, details, mask] = eCAP_amplitude(...):
%       - a: the amplitude (or amplitude list is a cell array was given as
%         argument).
%       - details: a 2x2 matrix with latency and value of the minimum on
%         first row, and same for the maximum on second row; or a list of
%         such matrices.
%       - mask: NaN or 1 depending on whether the amplitude measurement is
%         considered valid; or a list of NaN and ones.
%
%   The amplitude is found by substracting the first minimum to the
%   subsequent maximum. An eCAP is considered valid if the first minimum
%   happens after 250 �s and if the maximum does not occure
%   before 10 �s after the minimum. A warning is generated when this
%   happens. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia 2021, adapted from Etienne Gaudrain, 06-2012
% MRC Cognition and Brain Sciences Unit, Cambridge, UK
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% check if param details are provided
% this is required because in Cochlear, the ECAP recording starts with 0s
% being the start of the probe stimulus. For AB, 0s is the start of the
% masker stimulus, so it is important to know the Masker-Probe interval
if nargin > 2
    % if they are provided, take the MPI from the param structure
    MPI = param.masker_probe_delay_us/1000;
else
    % if they are not provided, assume MPI is 600us
    MPI = 0.6;
end

% initiate details, indeces, and counter
details = zeros(2);
mask = 1;
ii = 1;
pidx = 0; nlim = 0;

% find the index of the start of the probe stimulus
while pidx == 0
    if t(ii) > (MPI + 6*(param.phase_duration_us/1000)) % add time here to limit N-finding starting window
        pidx = ii;
    end
    ii = ii+1;
end

%find the maximum index for the N1 peak, 250us after the MPI index
% changed to 400us to avoid artefact for now - should really remove the
% artefact in a different way, but we can do that in analysis
while nlim == 0
    if t(ii) > (MPI + 6*(param.phase_duration_us/1000)) + 0.400
        nlim = ii;
    end
    ii = ii + 1;
end

% find N1 peak 
[vN, iN] = min(v(pidx:nlim));

% adjust N1 index for starting time
iN = pidx + iN - 1;

% change mask to NaN if the iN is less than 110us after the probe stimulus,
% or if it's simply collecting the final value of the v vector
if t(iN) + (MPI+2*(param.phase_duration_us/1000)) < 0.11 || iN == length(v)
    mask = NaN;
end

% put N1 peak details in the first row of the details matrix
details(1,:) = [t(iN), vN];

% find P2 peak
[vP, iP] = max(v(iN+1:end));

% adjust P2 index for iN index
iP = iN+iP;

% put P2 peak details in the second row of the details matrix
details(2,:) = [t(iP), vP];

% Calculate ECAP amplitude (but set to 0 if negative)
a = max(vP - vN, 0);
