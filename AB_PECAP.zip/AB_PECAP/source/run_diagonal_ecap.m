function Diagonal_ECAP_Data = run_diagonal_ecap(param)

% Diagonal_ECAP_Data = run_diagonal_ecap(param)
%   takes the electrodes with the MCL levels collected from running the
%   loudness GUI, and collects ECAPs along the diagonal with the recording
%   parameters specified within the param structure
%
%   Inputs:
%       - param:    structure containing recording parameters required for
%                   recording ECAPs
%   Outputs:
%       - Diagonal_ECAP_Data:   structure containing recorded ECAP data
%
% Required Software: 
%   signal_all = run_BEDCS_and_get_ECAP(h, param);
%   plot_ABCD_frames_AB(signal_all, param);
%   [a, details] = ecap_amplitude(ECAP, time_vector_ms, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Charlotte Garcia, 27 May 2021                                           %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% start timer
start = clock;

%% set diagonal parameters & initiate data structure
electrodes = param.electrodes;
MCL_levels = param.MCL_levels;
Diagonal_ECAP_Data = struct();

%% Loop through different electrodes
for ii = 1:length(electrodes)
    % Set parameters for individual ECAP
    param.electrode_masker = electrodes(ii);
    param.electrode_probe = electrodes(ii);
    if param.electrodes(ii) + param.rel_rec_EL >= 1 && ...
            electrodes(ii) + param.rel_rec_EL <= 16
        param.rec_EL = electrodes(ii) + param.rel_rec_EL;
    else
        param.rec_EL = electrodes(ii) - param.rel_rec_EL;
    end
    param.level_start_masker = MCL_levels(ii);         
    param.level_start_probe = MCL_levels(ii);          
    
    % create stimulas structure to pass to BEDCS
    stim_struct.ELrec = param.rec_EL;     
    stim_struct.Tp = param.phase_duration_us;
    stim_struct.Tdel = param.masker_probe_delay_us;
    stim_struct.level = [param.level_start_masker param.level_start_probe];
    stim_struct.Imasker = param.level_start_masker;
    stim_struct.Iprobe = param.level_start_probe;
    stim_struct.ELmasker = param.electrode_masker;
    stim_struct.ELprobe = param.electrode_probe;
    
    % create handls to pass to BEDCS
    if param.debug
        handle_BEDCS = [];
    else
        handle_BEDCS = actxserver('BEDCS2.CBEDCSApp');
        handle_BEDCS.Online = 1;
        handle_BEDCS.Visible = 0;


        [current_path, ~, ~] = fileparts(mfilename('fullpath'));
        full_filename = [current_path filesep param.exp_file];

        % Load the file if not already done
        if ~strcmp(handle_BEDCS.ExpFileName, full_filename)
            handle_BEDCS.LoadExpFile(full_filename)
        end

        % Update the stimulus properties
        fields = fieldnames(stim_struct);
        for i = 1:length(fields)
            if ~strcmp(fields{i}, 'level')
                handle_BEDCS.Let_ControlVarVal(fields{i},...
                    stim_struct.(fields{i}))
            end
        end
        
        % To allow stimulation above 24 uA in BEDCS verson 1.8.321
        % (this is unecessary in version 1.8.337)
        % this turns off the OLS error 
        handle_BEDCS.ULevelMode = 1;
        
    end
    
    % print out recording details
    fprintf(['\nECAP Diagonal Recording ' num2str(ii) ' of ' ...
        num2str(length(electrodes)) '\n']);
    fprintf('\tProbe EL:  %d\t\tProbe Level:  %d\n', ...
        param.electrodes(ii), param.MCL_levels(ii));
    fprintf('\tMasker EL: %d\t\tMasker Level: %d\n', ...
        param.electrodes(ii), param.MCL_levels(ii));
    fprintf('\tRecording EL: %d\n', param.rec_EL);
    
    % run BEDCS and collect ECAP
    tic
    signal_all = run_BEDCS_and_get_AP_ECAP(handle_BEDCS, param);
    toc
    
    % store signal and details in another structure
    Diagonal_ECAP_Data(ii).Probe = stim_struct.ELprobe;
    Diagonal_ECAP_Data(ii).Probe_lvl = stim_struct.level(2);
    Diagonal_ECAP_Data(ii).Masker = stim_struct.ELmasker;
    Diagonal_ECAP_Data(ii).Masker_lvl = stim_struct.level(1);
    Diagonal_ECAP_Data(ii).Recording = stim_struct.ELrec;
    Diagonal_ECAP_Data(ii).PDus = stim_struct.Tp;
    Diagonal_ECAP_Data(ii).MPIus = stim_struct.Tdel;
    Diagonal_ECAP_Data(ii).ECAP = signal_all.ECAP;
    Diagonal_ECAP_Data(ii).frames = signal_all;
    
end

% stop clock and display elapsed time for data collection
finish = clock;
diff = finish - start;
if round(diff(6)) > 0
    fprintf('\nDiagonal Total Elapsed Time: %d hours %d minutes %d seconds\n', ...
        diff(4), diff(5), round(diff(6)));
else
    fprintf('\nDiagonal Total Elapsed Time: %d hours %d minutes %d seconds\n', ...
        diff(4), diff(5)-1, 60 + round(diff(6)));
end