function [signal_all, time_vector_ms] = run_BEDCS_and_get_BC(h, param)

% [signal_all, time_vector_ms] = run_BEDCS_and_get_BC(h, param)
%   plays the BC stimulus through the BEDCS handle given the specified
%   parameters and variables indicated. The first time this is called in a
%   sequence, it will usually take 10-15 extra seconds to establish a
%   connection with BEDCS. After the first time, it's generally faster,
%   even if a new stimulus file is loaded.
%   This is an abbreviated version of the function 
%   [signal_all, time_vector_ms] = run_BEDCS_and_get_ECAP(h, param) that
%   only collects the B and C frames of the ECAP instead of all four A, B,
%   C, and D frames. This is required for the Panoramic ECAP data
%   collection in order to expedite the process of recording by missing out
%   redundant recording frames involved when recording ECAPs from all
%   combinations of masker and probe electrodes
%
%   Inputs:
%       - h:        BEDCS handle structure
%   Outputs:
%       - signal_all:       structure containing the ABCD frames, resultant
%                           ECAP waveform, and time vector collected from
%                           BEDCS streaming
%       - time_vector_ms:   time vector for ECAP frame recording
%
% Required Software: 
%   BEDCS 1.8 (make sure the COMs are configured correctly via serial port)
%   plot_ABCD_frames_AB(signal_all, param);
%   [a, details] = ecap_amplitude(ECAP, time_vector_ms, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Originally written by Francois Guerit                                   %
% Updated and Additional Comments added by Charlotte Garcia, May 2021     %
% MRC Cognition and Brain Sciences Unit, Cambridge, UK                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% make BEDCS visible if requested
if param.BEDCSVisible == 1
    h.Visible = 1;
end

% remove OLS error if running BEDCS 1.18.321
h.ULevelMode = 1;

% run BEDCS to collect the BC frames of an ECAP
too_soon = true;
while too_soon
    try h.MeasureNoSave; too_soon=false;%present pulse train
    catch, pause(.1);
    end
end
%
% CGarcia: figure out how to record all the individual sweeps!?!?
%   try h.Measure instead of h.MeasureNoSave
%   could also try to find the way to access 'store individual runs' from
%       the Measurements > Basic menu in BEDCS. Worst comes to worst, we 
%       could probably extract all the 50 sweeps or whatever literally from
%       saving a bunch of files in a specific file directory
%

% Collect the data
ST1 = h.CIIData{1}; %C
ST2 = h.CIIData{2}; %B

% this is the only way I managed so far to get the sampling frequency with 
% enough precision (multiply it by 1000 in BEDCS, in the analysis tab) (FG)
dt_us = h.Get_AnalVarValV('dt_us');

%% store results but don't plot because not all frames are recorded

time_vector_ms = (0:numel(ST1)-1)*dt_us/1000;

signal_all.time = time_vector_ms;
signal_all.B = ST2; % masker + probe
signal_all.C = ST1; % masker only
